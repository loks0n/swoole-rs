import sys,pathlib,json,os,importlib.util,shutil,hashlib
sys.path.insert(0,'/repo')
from corpus.upstream.run import prepare,run_cases
from tools.harness import parse_engines
spec=importlib.util.spec_from_file_location('tlsphp','/repo/tests/modules/tls/php.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
manifest=json.load(open('/repo/tests/modules/tls/php-verification-cases.json'));cases=[c for c in manifest['tests'] if c['path'].endswith('/verify_02.phpt')]
p=pathlib.Path('/out/instrumented-sandbox');p.mkdir();prepare(pathlib.Path('/reference'),p,cases,support_files=manifest['support_files'])
(p/'run-tests.php').unlink();shutil.copy('/usr/lib/php/20220829/build/run-tests.php',p/'run-tests.php')
engines=parse_engines(['hybrid=/artifacts/swoole.so','upstream=/artifacts/reference.so'],'/usr/bin/php',['pdo','pdo_sqlite','curl','sockets','tokenizer','posix','mbstring'])
rows=[]
for e in engines:
 for i in range(4):
  dest=pathlib.Path('/out/instrumented')/e.name/str(i);trace=str(pathlib.Path('/out')/('instrumented-'+e.name+'-'+str(i)+'.trace'))
  with m.matching_child_php(e,dest/'bin'):
   os.environ['LD_PRELOAD']='/out/observe.so';os.environ['M15_TLS_TRACE']=trace
   try:results,batch=run_cases(e,cases,p,dest,30,1)
   finally:os.environ.pop('LD_PRELOAD');os.environ.pop('M15_TLS_TRACE')
  row={'engine':e.name,'iteration':i,'results':results,'batch':batch,'trace':pathlib.Path(trace).read_text() if pathlib.Path(trace).exists() else ''};rows.append(row)
  pathlib.Path('/out/instrumented.json').write_text(json.dumps({'scope':'Instrumented diagnostic; interposed SSL_get_error logs its natural results, no original gate pass claim','engines':[x.metadata() for x in engines],'rows':rows},indent=2))
  print(e.name,i,[(v['status'],v.get('upstream_status')) for v in results.values()],row['trace'],flush=True)
  if 'ssl_shutdown' in row['trace']:break

#define _GNU_SOURCE
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int SSL_get_error(const SSL *ssl,int ret) {
 int entry_errno=errno;
 int (*real_error)(const SSL*,int)=dlsym(RTLD_NEXT,"SSL_get_error");
 errno=entry_errno;int result=real_error(ssl,ret);int saved=errno;
 Dl_info info={0};dladdr(__builtin_return_address(0),&info);
 const char *path=getenv("M15_TLS_TRACE");
 if(path){int fd=open(path,O_WRONLY|O_CREAT|O_APPEND,0600);if(fd>=0){char b[768];int n=snprintf(b,sizeof(b),"pid=%ld ret=%d class=%d errno=%d queue=%lu caller=%s\n",(long)getpid(),ret,result,entry_errno,ERR_peek_error(),info.dli_sname?info.dli_sname:"unknown");if(n>0&&n<(int)sizeof(b))write(fd,b,n);close(fd);}}
 errno=saved;return result;
}
